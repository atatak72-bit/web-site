import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import {
  Search, Filter, Edit2, Trash2, Pencil, CheckSquare,
  Square, ArrowUpDown, Tag, ShoppingBag, AlertCircle, Loader2,
} from 'lucide-react'
import { StatusBadge } from '../components/Badges'
import { EmptyState } from '../components/UI'
import { useStoreData } from '../lib/DataContext'
import { formatCurrency, formatDate, cn } from '../lib/utils'
import type { ListingStatus } from '../data/types'

export default function Listings() {
  const { listings, loading } = useStoreData()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<ListingStatus | 'all'>('all')
  const [selected, setSelected] = useState<string[]>([])
  const [sortField, setSortField] = useState<'title' | 'ebayPrice' | 'soldCount' | 'listedDate'>('listedDate')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')

  const filtered = useMemo(() => {
    let result = listings.filter(l => {
      const matchSearch = l.title.toLowerCase().includes(search.toLowerCase()) || l.asin.toLowerCase().includes(search.toLowerCase())
      const matchStatus = statusFilter === 'all' || l.status === statusFilter
      return matchSearch && matchStatus
    })
    result = [...result].sort((a, b) => {
      let av = a[sortField] as string | number
      let bv = b[sortField] as string | number
      if (typeof av === 'string' && typeof bv === 'string') {
        return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
      }
      return sortDir === 'asc' ? (av as number) - (bv as number) : (bv as number) - (av as number)
    })
    return result
  }, [listings, search, statusFilter, sortField, sortDir])

  const allSelected = filtered.length > 0 && selected.length === filtered.length

  function toggleSort(field: typeof sortField) {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDir('desc')
    }
  }

  function toggleSelect(id: string) {
    setSelected(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id])
  }

  function toggleSelectAll() {
    setSelected(allSelected ? [] : filtered.map(l => l.id))
  }

  const statusOptions: { value: ListingStatus | 'all'; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'active', label: 'Active' },
    { value: 'draft', label: 'Drafts' },
    { value: 'ended', label: 'Ended' },
    { value: 'out_of_stock', label: 'Out of Stock' },
    { value: 'unknown', label: 'Unknown' },
  ]

  if (loading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 text-brand-600 animate-spin" /></div>
  }

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by title or ASIN…"
            className="input pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as ListingStatus | 'all')}
            className="input w-auto"
          >
            {statusOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {selected.length > 0 && (
        <div className="flex items-center gap-3 bg-brand-50 border border-brand-200 rounded-lg px-4 py-2">
          <span className="text-sm font-medium text-brand-700">{selected.length} selected</span>
          <div className="flex-1" />
          <button className="btn-ghost text-sm"><Edit2 className="w-4 h-4" /> Edit Quantity</button>
          <button className="btn-ghost text-sm"><Tag className="w-4 h-4" /> Set Margin %</button>
          <button className="btn-ghost text-sm text-error-600 hover:bg-error-50"><Trash2 className="w-4 h-4" /> End Listings</button>
          <button className="btn-ghost text-sm" onClick={() => setSelected([])}>Clear</button>
        </div>
      )}

      <div className="card overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={ShoppingBag} title="No listings found" subtitle="Try adjusting your filters or connect a store and sync." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs text-slate-500 uppercase tracking-wider bg-slate-50">
                  <th className="px-4 py-3 w-10">
                    <button onClick={toggleSelectAll}>
                      {allSelected ? <CheckSquare className="w-4 h-4 text-brand-600" /> : <Square className="w-4 h-4 text-slate-300" />}
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => toggleSort('title')} className="flex items-center gap-1 hover:text-slate-700">
                      Listing <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">ASIN</th>
                  <th className="px-4 py-3 font-medium text-right">
                    <button onClick={() => toggleSort('ebayPrice')} className="flex items-center gap-1 hover:text-slate-700 ml-auto">
                      Price <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium text-right">Qty</th>
                  <th className="px-4 py-3 font-medium text-right">
                    <button onClick={() => toggleSort('soldCount')} className="flex items-center gap-1 hover:text-slate-700 ml-auto">
                      Sold <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => toggleSort('listedDate')} className="flex items-center gap-1 hover:text-slate-700">
                      Listed <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(listing => (
                  <tr key={listing.id} className="border-b border-slate-100 table-row-hover">
                    <td className="px-4 py-3">
                      <button onClick={() => toggleSelect(listing.id)}>
                        {selected.includes(listing.id) ? <CheckSquare className="w-4 h-4 text-brand-600" /> : <Square className="w-4 h-4 text-slate-300" />}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img src={listing.image} alt="" className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0" />
                        <Link to={`/listings/${listing.id}`} className="font-medium text-slate-900 hover:text-brand-600 truncate max-w-xs">
                          {listing.title}
                        </Link>
                        {listing.promoted && <span className="badge-info text-xs">Promoted</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-slate-500">{listing.asin}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="font-medium text-slate-900">{formatCurrency(listing.ebayPrice)}</div>
                      <div className="text-xs text-slate-400">cost {formatCurrency(listing.amazonPrice)}</div>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-700">{listing.quantity}</td>
                    <td className="px-4 py-3 text-right text-slate-700">{listing.soldCount}</td>
                    <td className="px-4 py-3"><StatusBadge status={listing.status} /></td>
                    <td className="px-4 py-3 text-slate-500 text-xs">{formatDate(listing.listedDate)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link to={`/listings/${listing.id}`} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-700 transition">
                          <Pencil className="w-4 h-4" />
                        </Link>
                        <button className="p-1.5 rounded-lg hover:bg-error-50 text-slate-500 hover:text-error-600 transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="px-4 py-3 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
          <span>Showing {filtered.length} of {listings.length} listings</span>
          <div className="flex gap-1">
            <button className="btn-ghost text-xs px-2 py-1" disabled>Previous</button>
            <button className="btn-ghost text-xs px-2 py-1" disabled>Next</button>
          </div>
        </div>
      </div>
    </div>
  )
}
