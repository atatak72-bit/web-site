import { useState, useEffect, useMemo } from 'react'
import {
  Search, PackagePlus, Upload, Save, Link2,
  AlertCircle, CheckCircle2, Sparkles, Layers, FileText, Loader2,
  ShieldAlert, ListChecks, Plus, Trash2
} from 'lucide-react'
import { cn, formatCurrency, calculateEbayPrice, type PricingTierInput } from '../lib/utils'
import { useStoreData } from '../lib/DataContext'
import { supabase } from '../lib/supabase'
import type { AmazonProduct } from '../lib/useData'
import { addAmazonProduct } from '../services/productService'

type Tab = 'single' | 'bulk' | 'bulk-runs' | 'single-drafts' | 'bulk-drafts' | 'link'

interface ItemSpecific {
  key: string
  value: string
}

const HARDCODED_BLOCKS = ['amazon', 'amazon basics', 'amazonbasics', 'prime', 'fulfilled by amazon']

// Helper: truncate title safely to 80 chars (word-safe)
function truncateTitleTo80(title: string) {
  if (!title) return ''
  let t = title.trim()
  if (t.length <= 80) return t
  t = t.slice(0, 80)
  const lastSpace = t.lastIndexOf(' ')
  if (lastSpace > 60) {
    t = t.slice(0, lastSpace)
  }
  return t.trim()
}

// Helper: strip HTML using DOMParser when available
function stripHtml(html: string) {
  if (!html) return ''
  try {
    const doc = new DOMParser().parseFromString(html, 'text/html')
    return doc.body.textContent || ''
  } catch {
    return html.replace(/<\/?[^>]+(>|$)/g, '')
  }
}

// Build a detailed description preferring long/clean sources and keeping bullets/specs
function buildDetailedDescription(product: any) {
  const descCandidates: string[] = []

  // Favor long/HTML description fields (strip HTML)
  const htmlFields = ['description', 'product_description', 'long_description', 'editorial_review']
  for (const f of htmlFields) {
    if (product?.[f] && typeof product[f] === 'string' && product[f].trim().length > 30) {
      descCandidates.push(stripHtml(product[f]).trim())
    }
  }

  // about_this_item or bullet arrays
  if (Array.isArray(product?.about_this_item) && product.about_this_item.length) {
    descCandidates.push(product.about_this_item.map((b: any) => stripHtml(String(b))).join('\n'))
  }
  const bullets = product?.bullet_points ?? product?.feature_bullets ?? product?.features
  if (Array.isArray(bullets) && bullets.length) {
    const cleaned = bullets.map((b: any) => typeof b === 'string' ? stripHtml(b).trim() : '').filter(Boolean)
    if (cleaned.length) descCandidates.push('Key Features:\n• ' + cleaned.join('\n• '))
  }

  // product_overview, product_information, details
  const textFields = ['product_overview', 'product_information', 'details']
  for (const f of textFields) {
    if (product?.[f] && (typeof product[f] === 'string' || Array.isArray(product[f]))) {
      if (Array.isArray(product[f])) {
        descCandidates.push(product[f].map((x: any) => stripHtml(String(x))).join('\n'))
      } else {
        descCandidates.push(stripHtml(product[f]))
      }
    }
  }

  // specifications as Key: Value
  if (product?.specifications) {
    const specsLines: string[] = []
    if (Array.isArray(product.specifications)) {
      product.specifications.forEach((s: any) => {
        if (s && (s.key || s.name) && (s.value || s.val)) specsLines.push(`${s.key ?? s.name}: ${s.value ?? s.val}`)
        else if (typeof s === 'string') specsLines.push(stripHtml(s))
      })
    } else if (typeof product.specifications === 'object') {
      Object.entries(product.specifications).forEach(([k, v]) => specsLines.push(`${k}: ${v}`))
    }
    if (specsLines.length) descCandidates.push('Specifications:\n' + specsLines.join('\n'))
  }

  // Fallback: combine several small sources into one long block (de-duplicate)
  const joined = Array.from(new Set(descCandidates)).join('\n\n').trim()
  if (joined.length > 30) return joined

  // Ultimate fallback: title + bullets + some attributes
  const fallbackParts: string[] = []
  if (product?.title) fallbackParts.push(product.title)
  if (Array.isArray(bullets) && bullets.length) fallbackParts.push('Key Features:\n• ' + bullets.join('\n• '))
  if (product?.brand) fallbackParts.push(`Brand: ${product.brand}`)
  return fallbackParts.join('\n\n').trim()
}

// Item specifics extraction helpers (DO NOT add ASIN as an item specific)
const KNOWN_KEYS_MAP: Record<string, string> = {
  brand: 'Brand',
  manufacturer: 'Brand',
  mpn: 'MPN',
  model: 'Model',
  color: 'Color',
  size: 'Size',
  material: 'Material',
  dimensions: 'Dimensions',
  weight: 'Weight',
  asin: 'ASIN',
  ean: 'EAN',
  upc: 'UPC'
}

function normalizeKey(k: string) {
  const key = k.toLowerCase().replace(/[_\s]+/g, ' ').trim()
  return KNOWN_KEYS_MAP[key] ?? k.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
}

function extractItemSpecifics(product: any): { key: string; value: string }[] {
  const seen = new Map<string, string>()
  function add(k: string, v: any) {
    if (!k || v == null) return
    const nk = normalizeKey(k)
    const nv = String(v).trim()
    if (!nv) return
    const keyLower = nk.toLowerCase()
    if (!seen.has(keyLower)) {
      seen.set(keyLower, nv)
    } else {
      const prev = seen.get(keyLower)!
      if (prev.length < nv.length) seen.set(keyLower, nv)
    }
  }

  // Important: do NOT add ASIN as item specific; keep meta separate
  add('Brand', product?.brand ?? product?.manufacturer)
  add('MPN', product?.mpn ?? product?.manufacturerPartNumber)
  add('Model', product?.model)
  // add other fields from common containers
  const sources = [product?.specifications, product?.attributes, product?.product_information, product?.details, product?.product_overview]
  for (const src of sources) {
    if (!src) continue
    if (Array.isArray(src)) {
      src.forEach((item: any) => {
        if (item && typeof item === 'object') {
          const k = item.key ?? item.name ?? item.label
          const v = item.value ?? item.val ?? item.content
          add(k, v)
        } else if (typeof item === 'string') {
          const [k, ...rest] = item.split(':')
          if (rest.length) add(k, rest.join(':').trim())
        }
      })
    } else if (typeof src === 'object') {
      Object.entries(src).forEach(([k, v]) => {
        if (typeof v === 'string' || typeof v === 'number') add(k, v)
        else if (Array.isArray(v)) add(k, v.join(', '))
      })
    } else if (typeof src === 'string') {
      src.split('\n').forEach(line => {
        const [k, ...rest] = line.split(':')
        if (rest.length) add(k, rest.join(':').trim())
      })
    }
  }

  // bullets colon parsing (e.g. "Length: 100FT")
  const bullets = product?.bullet_points ?? product?.feature_bullets ?? product?.features
  if (Array.isArray(bullets)) {
    bullets.forEach((b: any) => {
      if (typeof b !== 'string') return
      const [k, ...rest] = b.split(':')
      if (!rest.length) return
      add(k, rest.join(':').trim())
    })
  }

  const result: { key: string; value: string }[] = []
  for (const [k, v] of seen.entries()) {
    result.push({ key: k.replace(/\b\w/g, c => c.toUpperCase()), value: v })
  }
  return result
}

// Simple category suggestion heuristic (use as initial suggestion; recommend backend eBay taxonomy call for production)
function detectCategorySuggestion(product: any) {
  if (product?.category && typeof product.category === 'string' && product.category.length > 2) {
    return product.category
  }
  if (Array.isArray(product?.browse_nodes) && product.browse_nodes.length) {
    const labels = product.browse_nodes.map((n: any) => n?.name || n?.label).filter(Boolean)
    if (labels.length) return labels.join(' > ')
  }
  const title = (product?.title ?? '').toLowerCase()
  if (title.includes('wire') || title.includes('cable')) return 'Electronics > Accessories > Cables & Interconnects'
  if (title.includes('shirt') || title.includes('t-shirt')) return 'Clothing, Shoes & Accessories > Men'
  return ''
}

export default function ListItems() {
  const { stores, fetchAmazonProduct } = useStoreData()
  const [tab, setTab] = useState<Tab>('single')
  const [asin, setAsin] = useState('')
  const [product, setProduct] = useState<AmazonProduct | null>(null)
  const [fetching, setFetching] = useState(false)
  const [fetchError, setFetchError] = useState<string | null>(null)
  const [publishing, setPublishing] = useState(false)
  const [publishError, setPublishError] = useState<string | null>(null)
  const [publishSuccess, setPublishSuccess] = useState<string | null>(null)
  const [generatingTitle, setGeneratingTitle] = useState(false)
  const [promoted, setPromoted] = useState(true)

  // Form States
  const [reviewTitle, setReviewTitle] = useState('')
  const [reviewDescription, setReviewDescription] = useState('')
  const [reviewPrice, setReviewPrice] = useState('')
  const [quantity, setQuantity] = useState(1)
  const [selectedCategory, setSelectedCategory] = useState<string>('')

  // Item Specifics State
  const [itemSpecifics, setItemSpecifics] = useState<ItemSpecific[]>([])

  // Settings State
  const [pricingTiers, setPricingTiers] = useState<PricingTierInput[]>([])
  const [ebayFeePct, setEbayFeePct] = useState(13.25)
  const [ebayFixedFee, setEbayFixedFee] = useState(0.30)
  const [pricingEnabled, setPricingEnabled] = useState(true)
  const [veroBlockKeywords, setVeroBlockKeywords] = useState<string[]>([])

  const activeStore = stores.find(s => s.active) || stores[0]

  useEffect(() => {
    if (!activeStore?.id) return
    let cancelled = false

    async function loadSettings() {
      const [settingsRes, tiersRes, veroRes] = await Promise.all([
        supabase.from('pricing_settings').select('pricing_enabled, ebay_percentage_fee, ebay_fixed_fee').eq('store_id', activeStore!.id).maybeSingle(),
        supabase.from('pricing_rules').select('min_price, max_price, profit_pct, fixed_profit, sort_order').eq('store_id', activeStore!.id).order('sort_order', { ascending: true }),
        supabase.from('store_vero_settings').select('block_keywords').eq('store_id', activeStore!.id).maybeSingle(),
      ])
      if (cancelled) return

      if (settingsRes.error) {
        console.error('pricing_settings error', settingsRes.error)
      } else if (settingsRes.data) {
        setPricingEnabled(settingsRes.data.pricing_enabled ?? true)
        setEbayFeePct(Number(settingsRes.data.ebay_percentage_fee) || 13.25)
        setEbayFixedFee(Number(settingsRes.data.ebay_fixed_fee) || 0.30)
      }

      if (tiersRes.error) {
        console.error('pricing_rules error', tiersRes.error)
      } else if (tiersRes.data) {
        setPricingTiers(tiersRes.data.map(r => ({
          min: Number(r.min_price) || 0,
          max: Number(r.max_price) || 999999,
          profitPct: Number(r.profit_pct) || 20,
          fixProfit: Number(r.fixed_profit) || 0,
        })))
      }

      if (veroRes.error) {
        console.error('store_vero_settings error', veroRes.error)
      } else if (veroRes.data) {
        setVeroBlockKeywords((veroRes.data.block_keywords as string[]) || [])
      }
    }

    void loadSettings()
    return () => { cancelled = true }
  }, [activeStore?.id])

  // Precompile VeRO patterns (regex + substrings) for robust detection
  const veroPatterns = useMemo(() => {
    const all = [...HARDCODED_BLOCKS, ...(veroBlockKeywords || [])]
      .map(k => (k || '').trim())
      .filter(Boolean)
      .map(k => k.toLowerCase())

    const regexes = all.map(k => {
      const esc = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const safe = /^[a-z0-9\s]+$/.test(k)
      return { keyword: k, re: safe ? new RegExp(`\\b${esc}\\b`, 'i') : null }
    })
    return { regexes, substrings: all }
  }, [veroBlockKeywords])

  const checkVeroViolation = (text: string): string | null => {
    if (!text) return null
    const lower = text.toLowerCase()
    for (const { keyword, re } of veroPatterns.regexes) {
      if (re && re.test(text)) return keyword
    }
    for (const k of veroPatterns.substrings) {
      if (!k) continue
      if (lower.includes(k)) return k
    }
    return null
  }

  const specificsText = useMemo(() => itemSpecifics.map(s => `${s.key} ${s.value}`).join(' '), [itemSpecifics])
  const titleViolation = useMemo(() => checkVeroViolation(reviewTitle), [reviewTitle, veroPatterns])
  const descViolation = useMemo(() => checkVeroViolation(reviewDescription), [reviewDescription, veroPatterns])
  const specificsViolation = useMemo(() => checkVeroViolation(specificsText), [specificsText, veroPatterns])

  const activeViolation = titleViolation 
    ? `Title contains restricted word: "${titleViolation}"` 
    : descViolation 
    ? `Description contains restricted word: "${descViolation}"` 
    : specificsViolation
    ? `Item Specifics contains restricted word: "${specificsViolation}"`
    : null

  const handleFetch = async () => {
    if (!asin.trim()) return
    setFetching(true)
    setFetchError(null)
    setProduct(null)
    try {
      const fetched: any = await fetchAmazonProduct(asin)

      // Normalize price safely
      const rawPrice = Number(fetched?.price ?? fetched?.amazon_price ?? fetched?.suggestedPrice ?? 0)
      const calcPrice = pricingEnabled && pricingTiers.length > 0
        ? (calculateEbayPrice(rawPrice, pricingTiers, ebayFeePct, ebayFixedFee)?.finalPrice ?? rawPrice)
        : Number(fetched?.suggestedPrice ?? rawPrice)

      setProduct(fetched)
      setReviewTitle(truncateTitleTo80(fetched?.title || ''))
      setReviewPrice(!Number.isNaN(calcPrice) ? Number(calcPrice).toFixed(2) : '0.00')

      // Safe stock check
      const isOut = String(fetched?.stock ?? '').toLowerCase().includes('out')
      setQuantity(isOut ? 0 : 1)

      // Description + specifics + category suggestion
      const builtDesc = buildDetailedDescription(fetched)
      setReviewDescription(builtDesc)

      const specs = extractItemSpecifics(fetched)
      setItemSpecifics(specs)

      const suggested = detectCategorySuggestion(fetched)
      setSelectedCategory(suggested || String(fetched?.category ?? ''))

    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Failed to fetch ASIN.')
    } finally {
      setFetching(false)
    }
  }

  const handleAddSpecific = () => {
    setItemSpecifics([...itemSpecifics, { key: '', value: '' }])
  }

  const handleRemoveSpecific = (index: number) => {
    setItemSpecifics(itemSpecifics.filter((_, i) => i !== index))
  }

  const handleSpecificChange = (index: number, field: 'key' | 'value', val: string) => {
    const updated = [...itemSpecifics]
    updated[index][field] = val
    setItemSpecifics(updated)
  }

  const handleGenerateTitle = () => {
    if (!product) return
    setGeneratingTitle(true)
    let cleaned = (reviewTitle || product.title || '')
      .replace(/amazon basics|amazonbasics|amazon|prime/gi, '')
      .replace(/\s{2,}/g, ' ')
      .trim()
    cleaned = truncateTitleTo80(cleaned)
    setReviewTitle(cleaned)
    setTimeout(() => setGeneratingTitle(false), 300)
  }

const handlePublish = async () => {
  if (!activeStore || !product || activeViolation) return
  setPublishing(true)
  setPublishError(null)

  try {
    const result = await addAmazonProduct({
      store_id: activeStore.id,
      asin: product.asin,
      title: reviewTitle,
      amazon_price: Number(product.price) || 0,
      requested_ebay_price: Number(reviewPrice) || undefined,
      category: selectedCategory || String(product.category || ''),
      quantity: Number(quantity) || 0,
      in_stock: quantity > 0,
      is_prime: Boolean((product as any)?.isprime),
      profit_margin: 20,
      ebay_fee: ebayFeePct,
      item_specifics: itemSpecifics,
      description: reviewDescription,
      images: product.images ?? [],
      promoted: promoted ?? false,
    })

    if (!result || !result.success) throw new Error(result?.message ?? 'Failed to publish')

    const anyRes: any = result
    const listingId = anyRes.ebay_listing_id ?? anyRes.listing_id ?? anyRes.ebayListingId
    const publishedFlag = anyRes.published === true || anyRes.is_published === true

    // Safely parse user-entered reviewPrice (NaN guard)
    const parsedReviewPrice = Number(reviewPrice)
    const reviewPriceValue = Number.isFinite(parsedReviewPrice) ? parsedReviewPrice : undefined

    // Use nullish coalescing grouped, then fallback to 0
    const calculatedPrice = (
      anyRes.calculatedebayprice ??
      anyRes.calculated_ebay_price ??
      anyRes.calculatedEbayPrice ??
      reviewPriceValue
    ) ?? 0

    if (listingId || publishedFlag) {
      setPublishSuccess(`Listed on eBay at ${formatCurrency(calculatedPrice)}`)
    } else {
      setPublishSuccess(result.message || 'Saved as draft / queued for publishing. Will update when published.')
    }

    setTimeout(() => {
      setPublishSuccess(null)
      setProduct(null)
      setAsin('')
      setItemSpecifics([])
    }, 2500)
  } catch (err) {
    setPublishError(err instanceof Error ? err.message : 'Failed to publish')
  } finally {
    setPublishing(false)
  }
}

  const tabs: { id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'single', label: 'Single Add', icon: PackagePlus },
    { id: 'bulk', label: 'Bulk Add', icon: Layers },
    { id: 'bulk-runs', label: 'Bulk Runs', icon: Upload },
    { id: 'single-drafts', label: 'Single Drafts', icon: FileText },
    { id: 'bulk-drafts', label: 'Bulk Drafts', icon: FileText },
    { id: 'link', label: 'Link to Amazon', icon: Link2 },
  ]

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Tab Bar */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors',
              tab === t.id ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-100',
            )}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'single' && (
        <div className="space-y-6">
          {/* Step 1: Add from Amazon */}
          <div className="card">
            <div className="card-header">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-full bg-brand-600 text-white flex items-center justify-center text-sm font-semibold">1</span>
                <h3 className="font-semibold text-slate-900">Add from Amazon</h3>
              </div>
            </div>
            <div className="card-body">
              <div className="flex flex-col sm:flex-row gap-3 max-w-2xl">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={asin}
                    onChange={e => setAsin(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') void handleFetch() }}
                    placeholder="Paste an Amazon URL or enter an ASIN"
                    className="input pl-9"
                  />
                </div>
                <button onClick={() => void handleFetch()} className="btn-primary" disabled={!asin.trim() || fetching}>
                  {fetching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  {fetching ? 'Fetching...' : 'Fetch Product'}
                </button>
              </div>
              {fetchError && <div className="mt-3 flex items-center gap-2 text-sm text-error-600 bg-error-50 rounded-lg px-4 py-2"><AlertCircle className="w-4 h-4 shrink-0" />{fetchError}</div>}
            </div>
          </div>

          {/* Amazon Snapshot Card */}
          {product && (
            <div className="card bg-slate-50/50 border border-slate-200">
              <div className="p-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Amazon Snapshot</h4>
                <div className="flex gap-4 items-start">
                  {product.images?.[0] && (
                    <img src={product.images[0]} alt={product.title || 'Product image'} className="w-20 h-20 object-cover rounded-lg border border-slate-200 bg-white" />
                  )}
                  <div className="space-y-1 text-sm">
                    <p className="font-medium text-slate-900">{product.title}</p>
                    <p className="text-xs text-slate-500">ASIN: <span className="font-mono">{product.asin}</span> | Brand: <span className="font-medium">{product.brand || 'N/A'}</span></p>
                    <p className="text-xs text-slate-500">Amazon Price: <span className="font-semibold text-slate-700">${Number(product.price ?? 0).toFixed(2)}</span> | Stock: <span className="text-emerald-600 font-medium">{product.stock || 'In Stock'}</span></p>
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 mt-1">
                      <CheckCircle2 className="w-3 h-3" /> Product fetched successfully
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Review before listing */}
          {product && (
            <div className="card">
              <div className="card-header">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full bg-brand-600 text-white flex items-center justify-center text-sm font-semibold">2</span>
                  <h3 className="font-semibold text-slate-900">Review before listing</h3>
                </div>
              </div>
              <div className="card-body space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="label mb-0">Title</label>
                      <button onClick={handleGenerateTitle} disabled={generatingTitle} className="text-xs text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1 disabled:opacity-50">
                        {generatingTitle ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />} Generate AI Title
                      </button>
                    </div>
                    <input 
                      className={cn("input", titleViolation && "border-red-500 bg-red-50 focus:ring-red-500 text-red-900")} 
                      value={reviewTitle} 
                      onChange={e => setReviewTitle(truncateTitleTo80(e.target.value))} 
                    />
                    <p className="mt-1 text-xs text-slate-400">eBay titles allow up to 80 characters</p>
                  </div>
                  <div>
                    <label className="label">eBay Price</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input 
                        className="input pl-7" 
                        value={reviewPrice} 
                        onChange={e => setReviewPrice(e.target.value)} 
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label">Quantity</label>
                    <input 
                      className="input" 
                      type="number" 
                      value={quantity} 
                      onChange={e => setQuantity(Number(e.target.value))} 
                    />
                  </div>
                  <div>
                    <label className="label">Category</label>
                    <div className="flex gap-2">
                      <select className="input flex-1" value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}>
                        <option value="">{product.category || 'Choose an eBay category'}</option>
                        {selectedCategory && <option value={selectedCategory}>{selectedCategory}</option>}
                      </select>
                      <button onClick={() => setSelectedCategory(detectCategorySuggestion(product))} className="btn-secondary text-xs">Suggest</button>
                    </div>
                  </div>
                </div>

                {/* Item Specifics Section */}
                <div className="border-t border-slate-200 pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <label className="label mb-0 flex items-center gap-2">
                      <ListChecks className="w-4 h-4 text-brand-600" /> Item Specifics ({itemSpecifics.length})
                    </label>
                    <button onClick={handleAddSpecific} className="text-xs text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1">
                      <Plus className="w-3.5 h-3.5" /> Add Specific
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {itemSpecifics.map((spec, idx) => (
                      <div key={idx} className="flex gap-2 items-center">
                        <input
                          placeholder="Name"
                          className="input text-xs w-1/3"
                          value={spec.key}
                          onChange={e => handleSpecificChange(idx, 'key', e.target.value)}
                        />
                        <input
                          placeholder="Value"
                          className="input text-xs flex-1"
                          value={spec.value}
                          onChange={e => handleSpecificChange(idx, 'value', e.target.value)}
                        />
                        <button onClick={() => handleRemoveSpecific(idx)} className="p-1 text-slate-400 hover:text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Promoted Listings Toggle */}
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <input 
                    type="checkbox" 
                    id="promoted" 
                    checked={promoted} 
                    onChange={e => setPromoted(e.target.checked)} 
                    className="w-4 h-4 text-brand-600 rounded border-slate-300" 
                  />
                  <label htmlFor="promoted" className="text-sm font-medium text-slate-700 cursor-pointer">
                    Add to eBay Promoted Listings
                  </label>
                </div>

                {/* Description */}
                <div>
                  <label className="label">Description</label>
                  <textarea
                    rows={8}
                    className={cn("input min-h-[160px] resize-y text-sm leading-relaxed font-sans", descViolation && "border-red-500 bg-red-50 focus:ring-red-500 text-red-900")}
                    value={reviewDescription}
                    onChange={e => setReviewDescription(e.target.value)}
                  />
                </div>

                {/* Images */}
                {product.images && product.images.length > 0 && (
                  <div>
                    <label className="label">Product Images</label>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      {product.images.map((image, idx) => (
                        <img key={idx} src={image} alt={product.title || `Image ${idx + 1}`} className="aspect-square w-full rounded-lg object-cover border border-slate-200" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Live Preview Box */}
                <div className="p-4 border border-slate-200 rounded-lg bg-slate-50">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preview</span>
                  <div className="flex gap-3 mt-2 items-center">
                    {product.images?.[0] && <img src={product.images[0]} alt={product.title || 'Preview image'} className="w-12 h-12 object-cover rounded border" />}
                    <div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">{reviewTitle || 'No title'}</p>
                      <p className="text-xs text-slate-600 font-bold mt-0.5">${reviewPrice}</p>
                    </div>
                  </div>
                </div>

                {/* VeRO Warning Box */}
                {activeViolation && (
                  <div className="flex items-center gap-3 p-3.5 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm font-medium">
                    <ShieldAlert className="w-5 h-5 text-red-600 shrink-0" />
                    <div>
                      <p className="font-semibold text-red-800">VeRO Violation Detected</p>
                      <p className="text-xs text-red-600 mt-0.5">{activeViolation}. Remove restricted words to enable listing.</p>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={handlePublish} 
                    disabled={publishing || !!activeViolation} 
                    className="btn-primary disabled:bg-slate-300 disabled:cursor-not-allowed disabled:border-slate-300"
                  >
                    {publishing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {publishing ? 'Publishing...' : 'List It'}
                  </button>
                  <button className="btn-secondary"><Save className="w-4 h-4" /> Save as Draft</button>
                </div>

                {publishError && <div className="text-sm text-error-600 bg-error-50 rounded-lg px-4 py-2">{publishError}</div>}
                {publishSuccess && <div className="flex items-center gap-2 text-sm text-success-600 bg-success-50 rounded-lg px-4 py-2"><CheckCircle2 className="w-4 h-4 shrink-0" />{publishSuccess}</div>}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}