const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ProductData {
  asin: string;
  title: string;
  brand: string;
  description: string;
  bulletPoints: string[];
  images: string[];
  mainImage: string;
  price: number;
  currency: string;
  stock: string;
  rating: number;
  ratingsTotal: number;
  category: string;
  specs: Record<string, string | number>;
  variations: Array<{
    asin: string;
    value: string;
    available: boolean;
    price: number;
  }>;
  suggestedPrice: number;
  isFBA?: boolean;
  deliveryDays?: number | null;
  filteredOut?: string;
}

interface FetchResult {
  success: boolean;
  product?: ProductData;
  error?: string;
}

interface FilterParams {
  min_rating?: number;
  min_review_count?: number;
  fba_only?: boolean;
  shipping_time_ranges?: string[];
  apply_tax?: boolean;
}

function passesFilters(
  rating: number,
  ratingsTotal: number,
  isFBA: boolean,
  deliveryDays: number | null,
  filters: FilterParams,
): { passed: boolean; reason?: string } {
  if (filters.min_rating != null && rating < filters.min_rating) {
    return { passed: false, reason: `Rating ${rating} below minimum ${filters.min_rating}` };
  }
  if (filters.min_review_count != null && ratingsTotal < filters.min_review_count) {
    return { passed: false, reason: `Reviews ${ratingsTotal} below minimum ${filters.min_review_count}` };
  }
  if (filters.fba_only && !isFBA) {
    return { passed: false, reason: "Not Fulfilled by Amazon (FBA-only enabled)" };
  }
  if (filters.shipping_time_ranges && filters.shipping_time_ranges.length > 0 && deliveryDays != null) {
    const matched = filters.shipping_time_ranges.some(range => {
      if (range === "0-2 days") return deliveryDays <= 2;
      if (range === "3-7 days") return deliveryDays >= 3 && deliveryDays <= 7;
      if (range === "8-13 days") return deliveryDays >= 8 && deliveryDays <= 13;
      if (range === "14 or more days") return deliveryDays >= 14;
      return false;
    });
    if (!matched) {
      return { passed: false, reason: `Delivery ${deliveryDays} days outside selected ranges` };
    }
  }
  return { passed: true };
}

function estimateTax(price: number): number {
  return Math.round(price * 0.07 * 100) / 100;
}

function extractAsin(input: string): string | null {
  const trimmed = input.trim();
  if (/^[A-Z0-9]{10}$/.test(trimmed)) return trimmed;
  const match = trimmed.match(/(?:\/dp\/|\/gp\/product\/|\/exec\/obidos\/ASIN\/|asin=)([A-Z0-9]{10})/i);
  return match ? match[1].toUpperCase() : null;
}

function calculateSuggestedPrice(price: number): number {
  const marked = price * 1.3;
  return Math.round(marked) - 0.01;
}

function num(v: unknown, fallback = 0): number {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const n = parseFloat(v.replace(/[^0-9.]/g, ""));
    return isNaN(n) ? fallback : n;
  }
  return fallback;
}

function str(v: unknown, fallback = ""): string {
  if (typeof v === "string") return v;
  if (v == null) return fallback;
  if (typeof v === "object") {
    const obj = v as Record<string, unknown>;
    return str(obj.name ?? obj.label ?? obj.title ?? obj.value ?? fallback, fallback);
  }
  return String(v);
}

function imageUrl(image: string | { url?: string; link?: string; src?: string }): string {
  return typeof image === "string" ? image : str(image.url || image.link || image.src);
}

interface OxylabsVariation {
  asin?: string;
  value?: string;
  is_available?: boolean;
  price?: number | string;
}

interface OxylabsProduct {
  title?: string;
  asin?: string;
  brand?: string;
  description?: string;
  bullets?: Array<string | { text?: string }>;
  images?: Array<string | { url?: string; link?: string; src?: string }>;
  price?: number | string;
  currency?: string;
  stock?: string | { status?: string; quantity?: number | string };
  rating?: number;
  ratings_total?: number;
  category?: string | { name?: string; id?: string; path?: Array<{ name?: string }> };
  variations?: OxylabsVariation[];
  attributes?: Record<string, string | number>;
  specs?: Record<string, string | number>;
}

interface OxylabsResponse {
  results?: Array<{ content?: OxylabsProduct; error?: string }>;
}

async function callOxylabs(username: string, password: string, asin: string): Promise<Response> {
  const payload = {
    source: "amazon_product",
    query: asin,
    domain: "com",
    geo_location: "90210",
    parse: true,
    render: "html",
  };

  const auth = btoa(`${username}:${password}`);

  return fetch("https://realtime.oxylabs.io/v1/queries", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${auth}`,
    },
    body: JSON.stringify(payload),
  });
}

function jsonResult(data: FetchResult, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

const SCRAPE_ERROR = "Failed to scrape live Amazon data for this ASIN. Please check scraper API key / proxy settings.";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const username = Deno.env.get("OXYLABS_USERNAME") || "bilal_5MJM";
    const primaryPassword = Deno.env.get("OXYLABS_PASSWORD") || "2124620+Kaya";
    const backupPassword = "2124620_Kaya";

    const body = await req.json() as { asin?: string; url?: string; filters?: FilterParams; store_id?: string };
    const input = body.asin || body.url || "";
    const asin = extractAsin(input);
    const filters: FilterParams = body.filters || {};

    if (!asin) {
      return jsonResult({
        success: false,
        error: "Could not extract a valid ASIN. Enter a 10-character ASIN or a full Amazon product URL.",
      }, 400);
    }

    let apiRes: Response;
    try {
      apiRes = await callOxylabs(username, primaryPassword, asin);
      if (apiRes.status === 401) {
        apiRes = await callOxylabs(username, backupPassword, asin);
      }
    } catch (fetchErr) {
      return jsonResult({
        success: false,
        error: `${SCRAPE_ERROR} (Network error: ${fetchErr instanceof Error ? fetchErr.message : "unknown"})`,
      }, 502);
    }

    if (!apiRes.ok) {
      const errText = await apiRes.text().catch(() => "");
      return jsonResult({
        success: false,
        error: `${SCRAPE_ERROR} (Oxylabs returned HTTP ${apiRes.status}${errText ? ": " + errText.slice(0, 200) : ""})`,
      }, 502);
    }

    let apiData: OxylabsResponse;
    try {
      apiData = await apiRes.json() as OxylabsResponse;
    } catch {
      return jsonResult({ success: false, error: SCRAPE_ERROR }, 502);
    }

    const firstResult = apiData.results?.[0];
    if (!firstResult?.content) {
      return jsonResult({
        success: false,
        error: `${SCRAPE_ERROR}${firstResult?.error ? " (" + firstResult.error + ")" : ""}`,
      }, 502);
    }

    const p = firstResult.content;
    const price = num(p.price);
    const title = str(p.title, "").trim();
    const images = (p.images || []).map(imageUrl).filter(Boolean);
    const mainImage = images[0] || "";
    const bulletPoints = (p.bullets || []).map(bullet => typeof bullet === "string" ? bullet : str(bullet.text)).filter(Boolean);
    const descParts: string[] = [];
    if (p.description) descParts.push(p.description);
    if (bulletPoints.length > 0) descParts.push(bulletPoints.join("\n"));
    const description = descParts.join("\n\n");

    const rating = num(p.rating, 0);
    const ratingsTotal = num(p.ratings_total, 0);

    const isFBA = (() => {
      const allSpecs = { ...(p.attributes || {}), ...(p.specs || {}) } as Record<string, string | number>;
      const fulfillment = str(allSpecs["fulfillment"] || allSpecs["Fulfillment"] || allSpecs["fulfilled_by"] || "").toLowerCase();
      return fulfillment.includes("amazon") || fulfillment.includes("fba") || fulfillment.includes("prime");
    })();

    const deliveryDays: number | null = (() => {
      const allSpecs = { ...(p.attributes || {}), ...(p.specs || {}) } as Record<string, string | number>;
      const delivery = str(allSpecs["delivery"] || allSpecs["shipping"] || "").toLowerCase();
      const match = delivery.match(/(\d+)\s*(?:to|-|–)\s*(\d+)\s*day/);
      if (match) return parseInt(match[2], 10);
      const single = delivery.match(/(\d+)\s*day/);
      return single ? parseInt(single[1], 10) : null;
    })();

    // Validate that we got real data — reject empty/incomplete responses.
    if (!title || price <= 0) {
      return jsonResult({
        success: false,
        error: `${SCRAPE_ERROR} (Received incomplete data — title: "${title || "empty"}", price: ${price})`,
      }, 502);
    }

    let effectivePrice = price;
    if (filters.apply_tax && price > 0) {
      effectivePrice = price + estimateTax(price);
    }

    const product: ProductData = {
      asin: str(p.asin, asin),
      title,
      brand: str(p.brand),
      description,
      bulletPoints,
      images,
      mainImage,
      price: effectivePrice,
      currency: str(p.currency, "USD"),
      stock: typeof p.stock === "object" ? str(p.stock.status, "Unknown") : str(p.stock, "Unknown"),
      rating,
      ratingsTotal,
      category: str(p.category),
      specs: { ...(p.attributes || {}), ...(p.specs || {}) },
      variations: (p.variations || []).map(v => ({
        asin: str(v.asin),
        value: str(v.value),
        available: v.is_available ?? true,
        price: num(v.price, 0),
      })),
      suggestedPrice: effectivePrice > 0 ? calculateSuggestedPrice(effectivePrice) : 0,
      isFBA,
      deliveryDays,
    };

    // Apply filters if provided.
    if (body.filters) {
      const filterResult = passesFilters(rating, ratingsTotal, isFBA, deliveryDays, filters);
      if (!filterResult.passed) {
        return jsonResult({
          success: false,
          error: `Product filtered out: ${filterResult.reason}`,
        }, 200);
      }
    }

    return jsonResult({ success: true, product });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return jsonResult({ success: false, error: `${SCRAPE_ERROR} (${message})` }, 500);
  }
});
